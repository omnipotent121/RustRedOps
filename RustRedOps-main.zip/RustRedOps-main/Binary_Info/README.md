# Binary Info 🦀

<p align="left">
	<a href="https://www.rust-lang.org/"><img src="https://img.shields.io/badge/made%20with-Rust-red"></a>
	<a href="#"><img src="https://img.shields.io/badge/platform-windows-blueviolet"></a>
</p>

- [Overview](#overview)
- [Usage](#usage)

# Overview

This is just a simple demonstration in case you want to include metadata in your Rust binary or change the associated icon.

# Usage 

Build the binary:
```sh
cargo build
```

Check your file's metadata and you'll find the information available.